# reviews/views.py

from django.shortcuts import render, redirect, get_object_or_404
from .models import Review
from .forms import ReviewForm

def product_reviews(request, product_id):
    product_reviews = Review.objects.filter(product_id=product_id)
    return render(request, 'reviews/product_reviews.html', {'reviews': product_reviews})

def add_review(request, product_id):
    product = get_object_or_404(Product, pk=product_id)

    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.product = product
            review.user = request.user
            review.save()
            return redirect('product_detail', product_id=product_id)
    else:
        form = ReviewForm()

    return render(request, 'reviews/add_review.html', {'form': form, 'product': product})
