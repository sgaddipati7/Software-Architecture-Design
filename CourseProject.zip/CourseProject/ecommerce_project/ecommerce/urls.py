# ecommerce/urls.py

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from .views import home

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('accounts/', include('ecommerce.apps.accounts.urls')),
    path('products/', include('ecommerce.apps.products.urls')),
    path('cart/', include('ecommerce.apps.cart.urls')),
    path('orders/', include('ecommerce.apps.orders.urls')),
    path('reviews/', include('ecommerce.apps.reviews.urls')),
    path('analytics/', include('ecommerce.apps.analytics.urls')),
    # Add other top-level URLs as needed
]

# Serving static files during development
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
