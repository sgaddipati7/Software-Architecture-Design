# orders/views.py

from django.shortcuts import render, redirect, get_object_or_404
from .models import Order
from ecommerce.apps.cart.models import Cart
from .forms import OrderForm

def order_history(request):
    orders = Order.objects.filter(user=request.user)
    return render(request, 'orders/order_history.html', {'orders': orders})

def create_order(request):
    cart = Cart.objects.filter(user=request.user)
    total_price = sum(item.product.price * item.quantity for item in cart)
    
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.user = request.user
            order.cart = cart
            order.total_price = total_price
            order.save()
            cart.delete()
            return redirect('order_history')
    else:
        form = OrderForm()

    return render(request, 'orders/create_order.html', {'form': form, 'total_price': total_price})
