# ecommerce/apps/products/__init__.py
