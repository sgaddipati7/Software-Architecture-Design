# products/urls.py

from django.urls import path
from .views import product_list, product_detail

urlpatterns = [
    path('list/', product_list, name='product_list'),
    path('detail/<int:product_id>/', product_detail, name='product_detail'),
    # Add other product-related URLs as needed
]
