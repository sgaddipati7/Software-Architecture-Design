# orders/urls.py

from django.urls import path
from .views import order_history, create_order

urlpatterns = [
    path('history/', order_history, name='order_history'),
    path('create/', create_order, name='create_order'),
    # Add other order-related URLs as needed
]
