# cart/views.py

from django.shortcuts import render, redirect, get_object_or_404
from .models import Cart
from ecommerce.apps.products.models import Product

def view_cart(request):
    user_cart = Cart.objects.filter(user=request.user)
    total_price = sum(item.product.price * item.quantity for item in user_cart)
    return render(request, 'cart/view_cart.html', {'cart': user_cart, 'total_price': total_price})

def add_to_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    cart_item, created = Cart.objects.get_or_create(user=request.user, product=product)
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return redirect('product_list')  # Redirect to product list or wherever you want

def remove_from_cart(request, cart_id):
    cart_item = get_object_or_404(Cart, pk=cart_id, user=request.user)
    cart_item.delete()
    return redirect('view_cart')
