# reviews/urls.py

from django.urls import path
from .views import product_reviews, add_review

urlpatterns = [
    path('product/<int:product_id>/', product_reviews, name='product_reviews'),
    path('add/<int:product_id>/', add_review, name='add_review'),
    # Add other review-related URLs as needed
]
