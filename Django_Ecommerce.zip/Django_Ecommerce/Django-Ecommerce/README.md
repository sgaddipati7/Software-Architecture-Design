# Django-Ecommerce

Ecommerce website built with Django 2.2.4, Python 3.11.5

![image](Django-Ecommerce\media_root\Image1.png)

`Product Slide`

![image](Django-Ecommerce\media_root\Image2.png)

`Shop Page`
![image](Django-Ecommerce\media_root\shop.png)

`Cart Page`
![image](C:\Users\dhava\OneDrive\Documents\Django_Ecommerce\Django-Ecommerce\media_root\cart.png)


# Installation

`pip install django`

`virtualenv env`

# For Mac/ Linux

`source env/bin/activate`

# For Window

`env\scripts\activate`

`pip install -r requirements.txt`

`python manage.py makemigrations`

`python manage.py migrate`

`python manage.py runserver`

