# analytics/urls.py

from django.urls import path
from .views import popular_products

urlpatterns = [
    path('popular-products/', popular_products, name='popular_products'),
    # Add other analytics-related URLs as needed
]
