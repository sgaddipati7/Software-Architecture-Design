from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from core.views import SignUpCartView, LoginCartView, CheckoutView, cart_view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('allauth.urls')),
    path('', include('core.urls', namespace='core')),
    path('socialaccount/signup.html', SignUpCartView.as_view(), name='signup_cart'),
    path('accounts/login/cart.html', LoginCartView.as_view(), name='login_cart'),
    path('accounts/signup/cart.html', LoginCartView.as_view(), name='login_cart'),
    path('cart.html', cart_view, name='cart'),
    path('checkout.html', CheckoutView.as_view(), name='checkout'),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL,
                          document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
