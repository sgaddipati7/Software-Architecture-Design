# ecommerce/apps/templates/__init__.py
