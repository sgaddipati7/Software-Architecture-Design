# analytics/views.py

from django.shortcuts import render
from .models import View

def popular_products(request):
    # Example: Retrieve the top 5 most viewed products
    popular_products = Product.objects.annotate(view_count=models.Count('view')).order_by('-view_count')[:5]
    return render(request, 'analytics/popular_products.html', {'popular_products': popular_products})
