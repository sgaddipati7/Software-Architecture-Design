# reviews/models.py

from django.db import models
from ecommerce.apps.products.models import Product
from django.contrib.auth import get_user_model

class Review(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    rating = models.IntegerField()
    comment = models.TextField()

    def __str__(self):
        return f"Review by {self.user.username} for {self.product.name}"
