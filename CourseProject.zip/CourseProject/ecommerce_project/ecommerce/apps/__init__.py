# ecommerce/apps/__init__.py
